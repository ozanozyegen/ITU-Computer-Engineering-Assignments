#include <linux/syscalls.h>
#include <linux/kernel.h>
#include <linux/cred.h>
#include <linux/sched.h>
#include <linux/pid.h>
#include <linux/proc_fs.h>
#include <linux/pid_namespace.h>
#include <linux/slab.h> 		//kmalloc
#include <linux/proc_fs.h>		//remove_proc_entry
#include <linux/errno.h>
#include <linux/string.h>

static void remove_task_from_proc(int pid){
	int i;
	int digit = 0;
	int temp = pid;
	while(temp>0){
		temp/=10;
		digit++;
	}


	int mul = 1;
	char* char_pid = kmalloc((digit+1)*sizeof(char), GFP_KERNEL);
	for(i=0;i<digit;i++){
		char_pid[digit-1-i] = ((pid/mul)%10)+'0';
		mul*=10;
	}
	char_pid[digit]='\0';


	printk("char_pid: --%s--", char_pid);
	remove_proc_subtree(char_pid, NULL);
}



asmlinkage long set_myFlag(pid_t pid, int flag){

	if(current_uid().val == 0){
		struct pid *pid_struct;
		struct task_struct *task;
		pid_struct = find_get_pid(pid);
		task = pid_task(pid_struct,PIDTYPE_PID);
		printk("Task with Pid First flag: %d, pid: %d\n",task->myFlag, task->pid);
		task->myFlag = flag;
		if(flag == 1) remove_task_from_proc(pid);
		printk("Task with Pid Changed flag: %d, pid: %d\n",task->myFlag, task->pid);

		return 0;
	}else{
		//printk("Error: %s\n",strerror_r(EACCES));
		return EACCES; // Permision denied
	}
}
